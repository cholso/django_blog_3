from django.contrib import admin
from polling.models import Poll

# Register your models here.

admin.site.register(Poll)


