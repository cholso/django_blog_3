# djangoblog
Polling and Blogging Application on Django
